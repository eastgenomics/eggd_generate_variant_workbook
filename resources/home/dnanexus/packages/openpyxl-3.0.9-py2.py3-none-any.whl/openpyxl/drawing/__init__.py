# Copyright (c) 2010-2021 openpyxl


from .drawing import Drawing
